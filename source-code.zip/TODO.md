#TODO

## Quick Analysis
 - Histogram
 - Resolution (**done**)
 - Pixel position when hovered (**done**)
 - Show color on hovered coordinat (**done**)

## Image Effects
 - Grey (**done**)
 - Contrast enhancement
 - Black & White
 - Brightness enhancement