package praktikum.pengolahan.citra.pojos;


public class ColorHistogram {
  private int
      bit,
      countRed,
      countGreen,
      countBlue;

  public int getBit() {
    return bit;
  }

  public void setBit(int bit) {
    this.bit = bit;
  }

  public int getCountRed() {
    return countRed;
  }

  public void setCountRed(int countRed) {
    this.countRed = countRed;
  }

  public int getCountGreen() {
    return countGreen;
  }

  public void setCountGreen(int countGreen) {
    this.countGreen = countGreen;
  }

  public int getCountBlue() {
    return countBlue;
  }

  public void setCountBlue(int countBlue) {
    this.countBlue = countBlue;
  }
}