package praktikum.pengolahan.citra.contracts;

public interface PerformOperationsTo {
  void pixelOn(int row, int column);
}
