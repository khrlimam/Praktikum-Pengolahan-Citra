package praktikum.pengolahan.citra.contracts;

public interface ApplyEffect {
  void apply();
}
