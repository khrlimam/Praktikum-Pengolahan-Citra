package praktikum.pengolahan.citra.contracts;

public interface UpdateUI {
  void update();
}
