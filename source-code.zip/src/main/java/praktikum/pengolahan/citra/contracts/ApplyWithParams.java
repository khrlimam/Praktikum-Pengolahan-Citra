package praktikum.pengolahan.citra.contracts;

public interface ApplyWithParams {
  void apply(int param);
}
