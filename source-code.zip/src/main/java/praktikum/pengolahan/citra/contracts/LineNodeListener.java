package praktikum.pengolahan.citra.contracts;

public interface LineNodeListener {
  void onMouseEntered();

  void onMouseExited();
}
