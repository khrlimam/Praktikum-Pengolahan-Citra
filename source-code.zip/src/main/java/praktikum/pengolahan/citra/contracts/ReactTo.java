package praktikum.pengolahan.citra.contracts;

public interface ReactTo {
  void pixelOn(int x, int y);
}
