package praktikum.pengolahan.citra.contracts;

public interface ExecutionDetail {
  void preExecution();
  void postExecution();
}
